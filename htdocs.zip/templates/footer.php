<?php if(!defined("PROTECT")) { exit("STOP!"); } ?>



<div id="footer">
<span>2017<br /> payment management</span>
</div>






<script type="text/javascript" src="/templates/js/payments.js"></script>

</body>
</html>