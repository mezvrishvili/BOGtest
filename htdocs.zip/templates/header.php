<?php if(!defined("PROTECT")) { exit("STOP!"); } ?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
<title>Payment Management</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="Content-Style-Type" content="text/css" />
<meta name="keywords" content="" />
<meta name="description" content="" />
<link href="/templates/css/style.css" rel="stylesheet" type="text/css" />
<script src="http://cdnjs.cloudflare.com/ajax/libs/json2/20140204/json2.min.js" type="text/javascript"></script>
</head>

<body>

<div id="main">


<div id="head-bg">
	<div id="head-binder">
		<div id="header">

			<div class="logo-div-left">
				<a href="/"><img alt="" src="/templates/images/logo.jpg" /></a>
			</div>

			<div class="text-div-right">
			<p>hello baby</p>
			</div>

		</div>
	</div> 
</div> 

