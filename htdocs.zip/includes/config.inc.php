<?php
if(!defined("PROTECT")) { exit("STOP!"); }

//-- MySQL konfiguracia
define("MYSQL_HOST", "localhost"); // Hosti (localhost)
define("MYSQL_USER", "management"); // Saxeli
define("MYSQL_PASS", "123123"); // Paroli
define("MYSQL_DATABASE", "management"); // Monacemta baza


//-- Direqtoriebis misamartebi
define("TPL_DIR", "templates/");
define("INC_DIR", "includes/");
define("CLS_DIR", "class/");

?>